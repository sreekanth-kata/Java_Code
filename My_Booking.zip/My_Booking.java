import java.util.*;

public class My_Booking {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Input Nr of rooms:");
        int Nr_rooms = scan.nextInt();

        int[][] room_booking = new int[Nr_rooms][365];

        for (int i = 0; i < Nr_rooms; i++) {                           //for 10 bookings
            for (int j = 0; j < 365; j++) {                           //for 10 bookings
                room_booking[i][j] = 0;
            }
        }
        String[] result=new String[50];

        int[] sd=new int[50];
        int[] ed=new int[50];

        int k = 1;
        int b=0;
        while (k != 2) {

            System.out.println("Enter startDay:");
            int startDate = scan.nextInt();
            sd[b]=startDate;
            System.out.println("Enter endDay:");
            int endDate = scan.nextInt();
            ed[b]=endDate;
            int days = endDate - startDate;
            boolean x_loop_must_break = false;
            int roomCount = 0;
            int dayCount;

            if (startDate < 0 || startDate > 365 || endDate < 0 || endDate > 365 || startDate > endDate) {
                result[b]="Decline";
                System.out.println("1: continue Booking\n2: Exit");
                k=scan.nextInt();
                b=b+1;
                continue;
            }

            for (int i = 0; i < Nr_rooms; i++) {
                dayCount = 0;
                for (int j = startDate; j <= endDate; j++) {
                    if (room_booking[i][j] != 1) {
                        dayCount = dayCount + 1;
                    }
                }
                if (dayCount == days + 1) {
                    for (int j = startDate; j <= endDate; j++) {
                        room_booking[i][j] = 1;
                    }
                    result[b] = "ACCEPT";
                    x_loop_must_break = true;
                    break;
                }
                if (x_loop_must_break == true) {
                    break;
                }
                roomCount += 1;
                if (roomCount == Nr_rooms) {
                    result[b] = "Decline";
                }

            }
            System.out.println("1: continue Booking\n2: Exit");
            k=scan.nextInt();
            b=b+1;
        }
        System.out.println("              startDate     EndDate       Result");
        for(int m=0;m<b;m++)
            System.out.println("Booking "+(m+1)+"         "+sd[m]+"          "+ed[m]+"           "+result[m]);
    }
}

