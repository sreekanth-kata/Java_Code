import java.util.*;

// To make reservations of rooms for clients in  a hotel
public class My_Booking {
    static Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.println("Input Nr of rooms:");           //Input the size of hotel(number of identical roomss)
        int Nr_rooms = scan.nextInt();

        int[][] room_booking = new int[Nr_rooms][365];      //2D array to keep track of reservations
        for (int i = 0; i < Nr_rooms; i++) {
            for (int j = 0; j < 365; j++) {
                room_booking[i][j] = 0;                     //Initially all rooms in the array are empty
            }
        }

        String[] result = new String[50];                    //let's assume there are 50 bookings possible in total

        int[] sd = new int[50];
        int[] ed = new int[50];

        int b=0;
        int k = 1;
        while (k != 2) {

            System.out.println("Enter startDay:");
            int startDate = scan.nextInt();
            sd[b] = startDate;
            System.out.println("Enter endDay:");
            int endDate = scan.nextInt();
            ed[b]=endDate;
            int days = endDate - startDate;
            boolean x_loop_must_break = false;
            int roomCount = 0;
            int dayCount;

            if (startDate < 0 || startDate > 365 || endDate < 0 || endDate > 365 || startDate > endDate) {      //Requests accepted for the planning period
                result[b]="Decline";
                System.out.println("1: continue Booking\n2: Exit");
                k=scan.nextInt();
                b=b+1;
                continue;
            }

            for (int i = 0; i < Nr_rooms; i++) {
                dayCount = 0;
                for (int j = startDate; j <= endDate; j++) {
if (room_booking[i][j] != 1) {                                                                        //Check if already booked
                        dayCount = dayCount + 1;
                    }
                }
                if (dayCount == days + 1) {
                    for (int j = startDate; j <= endDate; j++) {
                    room_booking[i][j] = 1;                                                           //Assign a value "1 or x" for the reservations being booked.
                    }
                    result[b] = "ACCEPT";
                    x_loop_must_break = true;
                    break;
                }
                if (x_loop_must_break == true) {
                    break;
                }
                roomCount += 1;
                if (roomCount == Nr_rooms) {
                    result[b] = "Decline";
                }

            }
            System.out.println("1: continue Booking\n2: Exit");
            k=scan.nextInt();
            b=b+1;
        }
        System.out.println("              startDate     EndDate       Result");
        for(int m=0;m<b;m++)
            System.out.println("Booking "+(m+1)+"         "+sd[m]+"          "+ed[m]+"           "+result[m]);
    }
}

